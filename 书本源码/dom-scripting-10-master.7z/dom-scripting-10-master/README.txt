For an index of all the code samples, double click on index.html.

To view the markup and JavaScript, navigate to the relevant folder and open up the .html and .js files in a text editor.

Don't forget to visit the website of the book: http://domscripting.com/